package com.roozbehzarei.webview.ui.theme

import androidx.compose.material3.Typography

val SuperWebViewTypography = Typography()
